#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x427e0e0b, "module_layout" },
	{ 0x45a30ebd, "kmalloc_caches" },
	{ 0xd65ba617, "dev_set_drvdata" },
	{ 0x4aabc7c4, "__tracepoint_kmalloc" },
	{ 0xd565abb8, "usb_deregister_dev" },
	{ 0xa06b69ee, "mutex_unlock" },
	{ 0x285ed7d, "mutex_trylock" },
	{ 0x25957f3c, "kmem_cache_alloc_notrace" },
	{ 0xef44f53c, "usb_deregister" },
	{ 0x5efe39bd, "__mutex_init" },
	{ 0xb72397d5, "printk" },
	{ 0xb4390f9a, "mcount" },
	{ 0x50592bc3, "usb_register_dev" },
	{ 0x4251e006, "usb_get_dev" },
	{ 0x74fbd655, "usb_bulk_msg" },
	{ 0xa18e5442, "usb_find_interface" },
	{ 0x37a0cba, "kfree" },
	{ 0xd8f45033, "usb_register_driver" },
	{ 0x362ef408, "_copy_from_user" },
	{ 0xe12a9232, "dev_get_drvdata" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "7E4322733046C091FB7CB3D");
